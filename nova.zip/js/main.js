let month = 3;
let investment = 500;

function month_prettify (n) {
  return Math.ceil(n);
}
function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function investment_prettify (n, coma = true) {
  let r = Math.ceil(n/250)*250;
  return coma ? numberWithCommas(r) : r;
}


function calcProfit() {
  const p = numberWithCommas(month*investment*2+investment);
  console.log(month, investment)
  $('#profit').html(`${p}$`)
  return 
}

$("#input-0").ionRangeSlider({
  skin: "round",
  min: 250,
  max: 10000,
  from: 500,
  step: 1,
  postfix: "$",
  prettify_separator: ",",
  prettify: investment_prettify,
  onStart: function(data) {
    investment = investment_prettify(data.from, false);
    $('#investment').html(`${numberWithCommas(investment)}$`);
    calcProfit();
  },
  onChange: function(data) {
    
    investment = investment_prettify(data.from, false);
    console.log(investment)
    $('#investment').html(`${numberWithCommas(investment)}$`);
    calcProfit();
    
  }
});

$("#input-1").ionRangeSlider({
  skin: "round",
  min: 1,
  max: 12,
  from: 3,
  step: 0.01,
  postfix: " month",
  prettify: month_prettify,
  onStart: function(data) {
    month = month_prettify(data.from);
    $('#period').html(`${month} Month`);
    calcProfit();
  },
  onChange: function(data) {
    month = month_prettify(data.from);
    $('#period').html(`${month} Month`);
    calcProfit();
  }
});

$(window).scroll(function () {
  const headerHeight =  $('.header').height();
  if ($(this).scrollTop() > headerHeight) {
    $('.header').addClass('header--scrolled');
    $('.main-content').css({
      'paddingTop': headerHeight+'px'
    });
  } else {
    $('.main-content').css({
      'paddingTop': 0,
    });
    $('.header').removeClass('header--scrolled');
  }
});


(function() {
  const elem = document.querySelector("#parallax2");
  // Add event listener
  document.addEventListener("mousemove", parallax);
  // Magic happens here
  function parallax(e) {
      let _w = window.innerWidth/2;
      let _h = window.innerHeight/2;
      let _mouseX = e.clientX;
      let _mouseY = e.clientY;
      let _depth1 = `${50 - (_mouseX - _w) * 0.01}% ${50 - (_mouseY - _h) * 0.01}%`;
      let _depth2 = `${50 - (_mouseX - _w) * 0.02}% ${50 - (_mouseY - _h) * 0.02}%`;
      let _depth3 = `${50 - (_mouseX - _w) * 0.06}% ${50 - (_mouseY - _h) * 0.06}%`;
      let x = `${_depth3}, ${_depth3}, ${_depth3}`;
      elem.style.backgroundPosition = x;
  }

})();