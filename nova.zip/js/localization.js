function setLanguage(languageData) {
  //подставляем переводы
  $(".localization").text(function() {
    var caption = $(this).attr("caption");
    return window[languageData][caption];
  });
  //подсвечиваем активный язык
  if (languageData) {
    $('.drop').find('li').removeClass('drop__item-active');
    $(`#li-language-${languageData}`).addClass('drop__item-active');
  }
  //в инпут подставляем язык
  // $('#select').val(languageData);

  //подставляем картинку
  $('.slct-image').hide();
  $(`#language-${languageData}`).show();

}

function hideDropBlock() {
	$('.drop').hide();
}

$(document).ready(function() {
  setLanguage('en');
});


// Select

$('.slct').click(function(){
	/* Заносим выпадающий список в переменную */
	var dropBlock = $(this).parent().find('.drop');

	/* Делаем проверку: Если выпадающий блок скрыт то делаем его видимым*/
	if( dropBlock.is(':hidden') ) {
		dropBlock.show();

		$(this).addClass('active');
	} else {
		$(this).removeClass('active');
    hideDropBlock()
	}
	return false;
});

$('.drop').find('li').click(function(){
  var selectResult = $(this).attr('caption');
  setLanguage(selectResult);
  adaptStyles(selectResult);
  hideDropBlock();
});

function adaptStyles(languageData) {
  if (languageData == 'ru') {
    $('.numbers__item').addClass('numbers__item-ru');
  } else {
    $('.numbers__item').removeClass('numbers__item-ru');
  }
}